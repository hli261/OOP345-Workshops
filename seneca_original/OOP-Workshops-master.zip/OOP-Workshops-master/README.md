# OOP-Workshops

Workshops for OOP345 course in the Winter 2020 term.