#include "Word.h"
#include <cstdio> 
using namespace sdds;

int main() {
	programTitle();
	wordStats(true);
	printf("");
	return 0;
}
