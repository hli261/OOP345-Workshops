#ifndef SDDS_WORD_H // replace with relevant names
#define SDDS_WORD_H
namespace sdds {
    void wordStats(bool logOn);

    void programTitle();
}
#endif

